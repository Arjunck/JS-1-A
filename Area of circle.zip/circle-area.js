
    function CalculateArea(){
        var radius =document.form1.txtRadius.value;
        
        document.write("<P>r =" + (radius) + "; Area =" + (radius * radius * Math.PI) + ";</p>");

    }
   